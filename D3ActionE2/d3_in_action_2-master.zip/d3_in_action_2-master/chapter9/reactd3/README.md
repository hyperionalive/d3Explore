A [d3.js](https://d3js.org) dashboard using React built with [Create React App](https://github.com/facebookincubator/create-react-app).

`npm i` and `npm start` from the `/reactd3` and you should see a dashboard at `localhost:3000`