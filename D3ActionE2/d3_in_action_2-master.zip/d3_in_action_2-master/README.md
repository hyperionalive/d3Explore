[D3.js in Action 2nd Edition](https://www.manning.com/books/d3js-in-action-second-edition) code and examples.

[d3.js](https://d3js.org)

Everything is a self-contained example except for Chapter 9, which requires Node and NPM.